/* Copyright (C) 2026 Flia
 * SPDX-License-Identifier: GPL-3.0-only
 */

#include "nuvashalauncher-ui-feedback.h"
#include "nuvashalauncher-i18n.h"

GtkWidget *
nuvashalauncher_ui_loading_child (void)
{
  GtkBox *box = GTK_BOX (gtk_box_new (GTK_ORIENTATION_VERTICAL, 12));
  AdwSpinner *spinner = ADW_SPINNER (adw_spinner_new ());
  GtkLabel *label = GTK_LABEL (gtk_label_new (_("Loading…")));

  gtk_widget_set_valign (GTK_WIDGET (box), GTK_ALIGN_CENTER);
  gtk_widget_set_halign (GTK_WIDGET (box), GTK_ALIGN_CENTER);
  gtk_widget_set_valign (GTK_WIDGET (spinner), GTK_ALIGN_CENTER);
  gtk_widget_set_halign (GTK_WIDGET (spinner), GTK_ALIGN_CENTER);
  gtk_widget_add_css_class (GTK_WIDGET (label), "dim-label");
  gtk_box_append (box, GTK_WIDGET (spinner));
  gtk_box_append (box, GTK_WIDGET (label));

  return GTK_WIDGET (box);
}

void
nuvashalauncher_ui_clear_error_label (GtkLabel *label)
{
  gtk_label_set_text (label, NULL);
  gtk_widget_set_visible (GTK_WIDGET (label), FALSE);
}

void
nuvashalauncher_ui_cancel_dialog (GtkButton *button G_GNUC_UNUSED, gpointer user_data)
{
  adw_dialog_close (ADW_DIALOG (user_data));
}

void
nuvashalauncher_ui_show_toast (GtkWidget  *page,
                   GtkWidget  *overlay,
                   const char *message)
{
  AdwToast *toast = NULL;

  if (page == NULL || overlay == NULL ||
      gtk_widget_get_root (page) == NULL)
    return;

  toast = adw_toast_new (message);
  adw_toast_set_use_markup (toast, FALSE);
  adw_toast_overlay_add_toast (ADW_TOAST_OVERLAY (overlay), toast);
}

void
nuvashalauncher_ui_set_action_label (GtkWidget *button, const char *label)
{
  g_return_if_fail (GTK_IS_WIDGET (button));
  g_return_if_fail (label != NULL);

  gtk_widget_set_tooltip_text (button, label);
  gtk_accessible_update_property (GTK_ACCESSIBLE (button),
                                  GTK_ACCESSIBLE_PROPERTY_LABEL, label, -1);
}

void
nuvashalauncher_ui_prepare_icon_button (GtkWidget *button, const char *label)
{
  g_return_if_fail (GTK_IS_WIDGET (button));
  g_return_if_fail (label != NULL);

  gtk_widget_add_css_class (button, "flat");
  nuvashalauncher_ui_set_action_label (button, label);
}

void
nuvashalauncher_ui_prepare_dialog_content (GtkWidget *content)
{
  g_return_if_fail (GTK_IS_WIDGET (content));
  gtk_widget_add_css_class (content, "nuvashalauncher-dialog-content");
  gtk_widget_set_hexpand (content, TRUE);
  gtk_widget_set_vexpand (content, TRUE);
}
